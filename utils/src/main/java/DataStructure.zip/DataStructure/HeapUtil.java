package DataStructure;

import java.util.ArrayList;

/**
 * Created by mac on 06/04/2018.
 */
public class HeapUtil {


    /**
     * 输入n个整数，找出其中最小的K个数。例如输入4,5,1,6,2,7,3,8这8个数字，则最小的4个数字是1,2,3,4,。
     *
     * 最小堆问题，只需维护K大小的堆。
     *
     * Java PriorityQueue is implementioned by heap.
     * @param input
     * @param k
     * @return
     */
    public ArrayList<Integer> GetLeastNumbers_Solution(int [] input, int k) {

        //

        return null;

    }




}
